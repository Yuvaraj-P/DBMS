<!DOCTYPE html>
<html>
    <head>
        <title>register agri_officer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Register</h1>
           <br>
        <div class="insertbox">
        <form action="registerf.php" method="post">
            <div>
            <label class=label>F_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="F_id" required>
            </div>
		<div>
		<label class=label>fname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="fname" required> 
        </div>
        <div>
		<label class=label>lname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="lname" required>
        </div>
        <div>
        <label class=label>District</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="dist" required>
        </div>
        <div>
        <label class=label>Acre owned</label>&nbsp
		<input type="text" name="acre" required>
        </div>
        <div>
        <label class=label >email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="email" required>
        </div>
        <div>
        <label class=label>password</label>&nbsp&nbsp&nbsp&nbsp
		<input type="password" name="password" required>
        </div>
        <div>
        <label class=label>retype password</label>
		<input type="password" name="password1" required>
        </div>
        <div>
      <center>  <input type="submit" name="insert" value="ok" class=sbtn></center>
        </div>
        </form>
        </div>
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="../index.php"> <h3>Back</h3></a> </p>
    </div>
       
        </section>
    </body> 
</html>

<?php

if(isset($_POST['insert']))
{
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['F_id'];
    $f=$_POST['fname'];
    $l=$_POST['lname'];
    $a=$_POST['acre'];
    $dist=$_POST['dist'];
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $pass1=$_POST['password1'];
    if(!$pass=$pass1)
    {
        echo "password mismatch";
    }    
    else{
        
        $sqla="insert into farmer(F_id,fname,lname,acre,district,email,password) values
         ('$id','$f','$l','$a','$dist','$email','$pass')";
        $query=mysqli_query($con,$sqla);
        echo "insert sucessful....!";
    }
}

?>