<?php
include("../partials/headl.php"); 
?>
    <link href="../css/login.css" rel="stylesheet" type="text/css">
    <br>
    <hr>
        </header>
                <div class="container">
                    <div class="login-box">
                        <h2>Login</h2>    (agri_officer)                                                   
                          <div class="admin-form">
                              <form action="aflogin.php" method="post">
                              <div class="form-group">
                              <h4><i class="fa fa-user" aria-hidden="true"></i></h4>
                              <input type="text" name="user" value="" class="from-control" placeholder="email">
                              </div>
                              <div class="form-group">
                              <h4><i class="fa fa-lock" aria-hidden="true"></i></h4> <input type="password" name="pass" value="" class="from-control" placeholder="password" >
                              </div>
                                <div>
                                     <input type="submit" class="butn btn-succ" name="" value="submit">
                                </div>
                                
                             </form>
                          </div> 
                    </div>
                </div>         
</body>
</html>
<?php
    session_start();

$con=mysqli_connect('localhost','root');
if(!$con){
    echo "connection failed";
}
$db = mysqli_select_db($con,'farmer_db');
    if(isset($_POST['user']))
    {
    $userv=$_POST['user'];
    $passv=$_POST['pass'];
    $sql="select * from agri_officer where email='$userv' and password='$passv' ";
    $query = mysqli_query ($con,$sql); 
    $row=mysqli_num_rows($query);
        if($row==1)
        {
            echo "login sucessful....!";
            $_SESSION['user'] =$userv;
            header('location:../agri_off/afmainpage.php');
        }
        else
        {
            echo "login failed.....!";
            header('location:aflogin.php');
        }
    }
 ?>