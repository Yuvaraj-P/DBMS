<!DOCTYPE html>
<html>
    <head>
        <title>farmer-homepage</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!-- <link href="css/style.css" rel="stylesheet"> -->
    </head>
    <body>
    <header class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="navbar-brand" style="background-color:green; width:110px; color:white;">
    &nbsp&nbsp<i class="fa fa-leaf" aria-hidden="true"></i> E-farm       
    </div>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"> <i class="fa fa-home" aria-hidden="true"></i>  Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">| <i class="fa fa-map" aria-hidden="true"></i>  Map</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">| <i class="fa fa-building" aria-hidden="true" ></i> Agri Mall</a>
      </li>
      <li class="nav-item"><a class= "nav-link" href="">| <i class="fa fa-info-circle" aria-hidden="true"></i> About Us</a></li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        |<i class="fa fa-user" aria-hidden="true"></i>  Login As
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Admin</a>
          <a class="dropdown-item" href="#">Agri_officer</a>          
          <a class="dropdown-item" href="#">Dealer</a>
          <a class="dropdown-item" href="#">farmer</a>
          <a class="dropdown-item" href="#">Reg as a Farmer</a>
      </li>

    </ul>
    <!-- <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
  </div>
</nav>
</header>

            <h4>&nbspHOME</h4>
            <div class="jumbotron container">
            <div></div>
</div>
            <section class="container">
            
<div style="margin:40px;">
                <p>
            e-Farm is a bridge from the farm to the consumer's table.
             We do not warehouse, handle nor resell the products. e-Farmers’ profile pages are free, farmer - producers 
             set the inventory they wish to offer, the price and sell directly to the consumer.
              e-Farm coordinates the purchase and negotiates delivery rates. 
              Among the goals of e-Farm is for local farmers to sell otherwise unsold products, thus,
               reduce food waste, produce more, expand their businesses, and sell in markets where
                these products are highly sought and valued.
             Try us by opening a free e-Farmer profile. It is very easy to set up with our approval.
            </p>
            <p >
            
            research found that 30% -50% of the sustainable, organic, agro-ecological 
            products are lost, while the consumer cannot not find and buy them.</p>
            <p >
            
We found a large group of people with limited time to go out to search for products,
 limited time to search for farms, complaining about 
 <br> limited supplies at their supermarkets
 <br> limited farmers' markets
 <br> limited days and hours of farmers' markets
 <br> lack of quality and freshness of products at the supermarket 
 <br> and a longing to find the product they are
  looking for and buy direct from the source.
  <br> <br> To our surprise this positively resulted
   in the largest group of people.
   
Then, the initial idea evolved to make an e-commerce tool that helps the farmer and people
 meet to buy and sell, with home delivery. Direct from the farm to the consumer.
 </p>
 <p >
 
Parallel 18, an international startup accelerator by the Puerto Rico Science 
Technology & Research Trust and Microsoft’s Jumpstart accelerator out of San Juan,
 Puerto Rico have propelled our development and provided us the tools and resources
  to scale this globally.
            </p>
            </div>
</section>
        
          
            
        <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>       
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        
    </body>
</html>