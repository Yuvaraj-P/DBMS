<?php
include("partials/head.php"); 
?>

</header>
<section>
<br>
<hr class="hmr">

            <h5>&nbsp&nbsp&nbsp&nbsp&nbsp HOME</h5>
            <section class="container"> 
            
<div style="margin:40px;">
                <p>
            e-Farm is a bridge from the farm to the consumer's table.
             We do not warehouse, handle nor resell the products. e-Farmers’ profile pages are free, farmer - producers 
             set the inventory they wish to offer, the price and sell directly to the consumer.
              e-Farm coordinates the purchase and negotiates delivery rates. 
              Among the goals of e-Farm is for local farmers to sell otherwise unsold products, thus,
               reduce food waste, produce more, expand their businesses, and sell in markets where
                these products are highly sought and valued.
             Try us by opening a free e-Farmer profile. It is very easy to set up with our approval.
            </p>
            <p >
            
            research found that 30% -50% of the sustainable, organic, agro-ecological 
            products are lost, while the consumer cannot not find and buy them.</p>
            <p >
            
We found a large group of people with limited time to go out to search for products,
 limited time to search for farms, complaining about 
 <br> limited supplies at their supermarkets
 <br> limited farmers' markets
 <br> limited days and hours of farmers' markets
 <br> lack of quality and freshness of products at the supermarket 
 <br> and a longing to find the product they are
  looking for and buy direct from the source.
  <br> <br> To our surprise this positively resulted
   in the largest group of people.
   
Then, the initial idea evolved to make an e-commerce tool that helps the farmer and people
 meet to buy and sell, with home delivery. Direct from the farm to the consumer.
 </p>
 <p >
 
Parallel 18, an international startup accelerator by the Puerto Rico Science 
Technology & Research Trust and Microsoft’s Jumpstart accelerator out of San Juan,
 Puerto Rico have propelled our development and provided us the tools and resources
  to scale this globally.
            </p>
            </div>
</section>
</section>        
          
        <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>       
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        

<?php
include("partials/foot.php");

?>