<?php
include("partials/head.php"); 
?>
<br>
  <hr>
            <div>
            <h5>&nbsp&nbsp&nbsp&nbsp&nbsp Map view</h5>
            <section>
               <center> 
                   <h5>unirrigated-irrigated state wise map</h5>
                   <br>
               <img src="images/stat1.png" alt="unirrigated state map">
               <br><br><br>
               <h5>agricultural land</h5>
               <br><br><br>
                <img src="images/stats2.png" alt="agricultural land"> </center>
                <br><br><br>
            </section>
            </div>
          
            
        </header>
    
        <?php
include("partials/foot.php");

?>