<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/farmerlogin.php");
    }
    
    $email=$_SESSION['user'];
    $con=mysqli_connect('localhost','root','','farmer_db');        
    $sql="select F_id,fname from farmer where email='$email'";
    $q=mysqli_query($con,$sql);
    $r=mysqli_fetch_array($q); 
    $fid=$r['F_id'];
?>

<?php include("../partials/header.php");?>
        <nav class="padd">
        <section>
        <ul>
        <li><a href="farmermainpage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
        
        <li style="width:10px;"><i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        <ul>
        <li><a href="../login/logout.php"> LOG OUT</a></li>
        </ul>
        </ul>  
        </nav>
        <br><hr>        
        <div class="jumbotron container" id="jumbo">
        <h2>WELCOME </h2>&nbsp&nbsp&nbsp<?php echo "$r[fname]"; ?>   
        </div>  
         
        <ul id=list >
        <li><a href="soilcard.php?i=<?php echo $fid ?>"><i class="fa fa-tint" aria-hidden="true"></i> Soil helath card</a></li>
        <li><a href="viewf.php"><i class="fa fa-user" aria-hidden="true"></i> view other farmers</a></li>
        <li><a href="grown.php"><i class="fa fa-globe" aria-hidden="true"></i> Grown</a></li>
        <li><a href="sell.php">sell <i class="fa fa-pagelines" aria-hidden="true"></i> crop</a></li>
        <li><a href="viewp.php"><i class="fa fa-cogs" aria-hidden="true"></i> Products </a></li>
        <li><a href="viewac.php"><i class="fa fa-pagelines" aria-hidden="true"></i> see commodity</a></li>
        </ul>
        </section>
    </body> 
</html>