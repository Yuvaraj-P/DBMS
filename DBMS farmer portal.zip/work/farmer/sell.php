<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/farmerlogin.php");
    }
    $con=mysqli_connect('localhost','root','','farmer_db'); 
    $email=$_SESSION['user'];   
    $sql="select F_id from farmer where email='$email'";
    $q=mysqli_query($con,$sql);
    $r=mysqli_fetch_array($q); 
    $fid=$r['F_id'];
include("../partials/header.php");
?>

<link href="../css/soil.css" rel="stylesheet">
        <section>
        <nav class="padd">
        <section>
        <ul>
        <li><a href="farmermainpage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
        <li style="width:10px;float:right;margin-right:150px;"><i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        <ul>
        <li><a href="../login/logout.php"> LOG OUT</a></li>
        </ul>
        </ul>  
        </nav>
        <br><hr>
        <ul class="padd" >
        <li><a href="soilcard.php?i=<?php echo $fid ?>"><i class="fa fa-tint" aria-hidden="true"></i> Soil helath card</a></li>
        <li><a href="viewf.php"><i class="fa fa-user" aria-hidden="true"></i> view other farmers</a></li>
        <li><a href="grown.php"><i class="fa fa-globe" aria-hidden="true"></i> Grown</a></li>
        <li><a href="sell.php">sell <i class="fa fa-pagelines" aria-hidden="true"></i> crop</a></li>
        <li><a href="viewp.php"><i class="fa fa-cogs" aria-hidden="true"></i> Products </a></li>
        <li><a href="viewac.php"><i class="fa fa-pagelines" aria-hidden="true"></i> see commodity</a></li>
        </ul>
        </section>
        <form action="sellp.php" method="post"  enctype="multipart/form-data">
        <div class=card>
            <div>
            <label class=label >F_id : <?php echo "$fid" ?></label>
            </div>
            <div>
            <label class=label>Crop_ID</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp              
            <input type="text" name="cid" required >
            </div>
            <div>
            <label class=label>No of quintal</label>             
            <input type="text" name="nou"  required>
            </div>
            <div>
            <label class=label>Price/quintal:</label>                
            <input type="text" name="price"  required >
            </div>
            <br>
            <div>&nbsp&nbsp&nbsp
            <input class="subtn" type="file" name="fileToUpload" id="fileToUpload" required>
            </div>
            <div>
            <center> <input type="submit" name="sell" value="sell" class="subtn" ></center>
            </div>
        </form>
        
    </body> 
</html>
