<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/farmerlogin.php");
    }
?>
<!DOCTYPE html>
<html lang=en >
    <head>
        <title>view farmer</title>
       <link href="../css/tablestyle.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
    <center><a href="farmermainpage.php"> <h3>Home</h3></a></center>        
<?php
    $con=mysqli_connect('localhost','root','','farmer_db');
    $s=mysqli_query($con,"select * from farmer");
?>
<center>
<table class=conttable>
    <thead>
    <tr>
    <th>Ag_id</th>
    <th>Fname</th>
    <th>Lname</th>
    <th>Dirstict</th>
    <th>address</th>
    <th>E-mail</th>
    </tr>
    </thead>
    <?php 
    while($r=mysqli_fetch_array($s))
    {
    ?>
    <tbody>
    <tr>
    <td><?php echo $r['F_id'];?> </td>
    <td><?php echo $r['fname'];?> </td>
    <td><?php echo $r['lname'];?> </td>
    <td><?php echo $r['district'];?> </td>
    <td width=200px;><?php echo $r['address'];?> </td>    
    <td><?php echo $r['email'];?> </td>
    </tr>
    </tbody>
    
    <?php
    }
    ?>
    </table>
</center>
    </body>     
</html>
