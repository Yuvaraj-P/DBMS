<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/aflogin.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>view section</title>
       <link href="../css/tablestyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <center><a href="farmermainpage.php"> <h3>home</h3></a></center>        
<?php
    $con=mysqli_connect('localhost','root','','farmer_db');
    $s=mysqli_query($con,"select * from agri_commodity");
?>
<center>
<table class=conttable>
    <thead>
    <tr>
    <th>C_id</th>
    <th>Crop_name</th>
    <th>type</th>
    <th>descp</th>
    <th>season</th>
    </tr>
    </thead>
    <?php 
    while($r=mysqli_fetch_array($s))
    {
    ?>
    <tbody>
    <tr>
    <td><?php echo $r['C_id'];?> </td>
    <td><?php echo $r['c_name'];?> </td>
    <td><?php echo $r['type'];?> </td>
    <td width=200px;><?php echo $r['descp'];?> </td>    
    <td><?php echo $r['season'];?> </td>
    </tr>
    </tbody>
    
    <?php
    }
    ?>
    </table>
</center>
    </body>     
</html>
