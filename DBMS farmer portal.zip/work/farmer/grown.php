<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/farmerlogin.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>growncrops</title>
       <link href="../css/tablestyle.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
    <center><a href="farmermainpage.php"> <h3>Home</h3></a></center>        
<?php
    $con=mysqli_connect('localhost','root','','farmer_db');
    $s=mysqli_query($con,"call grown()");

?>
<center>
<table class=conttable>
    <thead>
    <tr>
    <th>Fname</th>
    <th>crop_name</th>
    </tr>
    </thead>
    <?php 
    while($r=mysqli_fetch_array($s))
    {
    ?>
    <tbody>
    <tr>
    <td><?php echo $r['fname'];?> </td>
    <td><?php echo $r['c_name'];?> </td>
    </tr>
    </tbody>
    
    <?php
    }
    ?>
    </table>
</center>
    </body>     
</html>
