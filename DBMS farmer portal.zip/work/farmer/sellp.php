<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/farmerlogin.php");
    }
    $con=mysqli_connect('localhost','root','','farmer_db'); 
    $email=$_SESSION['user'];   
    $sql="select F_id from farmer where email='$email'";
    $q=mysqli_query($con,$sql);
    $r=mysqli_fetch_array($q); 
    $fid=$r['F_id'];

$target_dir = "../uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["sell"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
if($_FILES['fileToUpload']['name'])
{
    $img=$_FILES["fileToUpload"]["name"];
   
    $cid=$_POST['cid'];
    $sql = "CALL sell ('$fid','$cid')";
    $query=mysqli_query($con,$sql);            
    $price=$_POST['price'];
    $nou=$_POST['nou'];
    
    $update="update agri_mall set price='$price',img='$img',quintal='$nou' where F_id='$fid' and C_id='$cid';";
    $query=mysqli_query($con,$update);
    $uploadOk = 1;
    header('location:../agrimall.php');
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>