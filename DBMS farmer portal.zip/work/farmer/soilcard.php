<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
    if(isset($_GET['i']))
    {
        $fid=$_GET['i'];
        $con=mysqli_connect('localhost','root','','farmer_db');                  
        $sql="select * from soil_health_card where F_id='$fid'";
        $q=mysqli_query($con,$sql);
        $r=mysqli_fetch_array($q);

    }
?>
<?php include("../partials/header.php");?>
<link href="../css/soil.css" rel="stylesheet">

    <body style="background-image:url(../images/soil.jpg); background-size: cover;">
        <section>
        <nav class="padd">
        <section>
        <ul>
        <li><a href="farmermainpage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
        <li style="width:10px;float:right;margin-right:150px;"><i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        <ul>
        <li><a href="../login/logout.php"> LOG OUT</a></li>
        </ul>
        </ul>  
        </nav>
        <br><hr>
        <ul class="padd" >
        <li><a href="soilcard.php?i=<?php echo $fid ?>"><i class="fa fa-tint" aria-hidden="true"></i> Soil helath card</a></li>
        <li><a href="viewf.php"><i class="fa fa-user" aria-hidden="true"></i> view other farmers</a></li>
        <li><a href="grown.php"><i class="fa fa-globe" aria-hidden="true"></i> Grown</a></li>
        <li><a href="sell.php">sell <i class="fa fa-pagelines" aria-hidden="true"></i> crop</a></li>
        <li><a href="viewp.php"><i class="fa fa-cogs" aria-hidden="true"></i> Products </a></li>
        <li><a href="viewac.php"><i class="fa fa-pagelines" aria-hidden="true"></i> see commodity</a></li>
        </ul>
        </section>
        <section>
            <br><br>
        <h5 style="color:lightgreen; width:300px;padding:7px; text-align:center; background:black" >
            &nbsp&nbsp&nbspsoil health card</h5>  
        <div class="card">
            F_id &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp:
             <?php echo "$r[F_id]" ?>
            <br><br>
             soil type &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
             : <?php echo "$r[soil_type]" ?>
             <br><br>
             recommended crops : <?php echo "$r[recom_c]" ?>
             <br><br>
             organic fertilizer &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp : <?php echo "$r[of]" ?> kg/A
             <br><br>
             urea &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
             :  <?php echo "$r[urea]" ?> kg/A
             <br><br>
             ssp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
             : <?php echo "$r[ssp]" ?> kg/A
             <br><br>
             dap &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
             :  <?php echo "$r[dap]" ?> kg/A
             <br><br>
             (NH4)2SO4 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :
             <?php echo "$r[ammonia]" ?> kg/A
             <br><br>
             cas &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
             : <?php echo "$r[cas]" ?> kg/A
              <br><br>
              cf &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
              : <?php echo "$r[cf]" ?> kg/A
        </div>
        <div style="text-align:center;">
    <p><a href="farmermainpage.php"> <h3>Back</h3></a>  </p>

    </div>
    </section>
    </body> 
</html>