<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/dealerlogin.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>view product</title>
       <link href="../css/tablestyle.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
    <center><a href="farmermainpage.php"> <h3>home</h3></a></center>        
<?php
    $con=mysqli_connect('localhost','root','','farmer_db');
    $s=mysqli_query($con,"select * from product");

?>
<center>
<table class=conttable>
    <thead>
    <tr>
    <th>P_id</th>
    <th>name</th>
    <th>description</th>
    <th>price</th>
    <th>type</th>
    <th>D_id</th>
    <th>rent</th>
    </tr>
    </thead>
    <?php 
    while($r=mysqli_fetch_array($s))
    {
    ?>
    <tdata>
    <tr>
    <td><?php echo $r['P_id'];?> </td>
    <td><?php echo $r['name'];?> </td>
    <td><?php echo $r['descp'];?> </td>
    <td><?php echo $r['price'];?> </td>    
    <td><?php echo $r['type'];?> </td>
    <td><?php echo $r['D_id'];?> </td>
    <td><?php echo $r['rent'];?> </td>
    </tr>
    </tdata>
    <?php
    }
    ?>
    </table>
    </center>
    </body>
    </html>