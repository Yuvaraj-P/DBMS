<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>register dealer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <h1 style="color:white; text-align:center;" >Dealer</h1>
        <br>
        <div class="insertbox">
        <form action="registerd.php" method="post">
        <div>
        <label class=label>D_id</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="D_id" required>
        </div>
		<div>
		<label class=label>fname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="fname" required> 
        </div>
        <div>
		<label class=label>lname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="lname" required>
        </div>
        <div>
        <label class=label>email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="email" required>
        </div>
        <div>
        <label class=label>password</label>&nbsp&nbsp&nbsp&nbsp
		<input type="password" name="password" required>
        </div>
        <div>
        <label class=label>organization</label>
		<input type="text" name="org" required>
        </div>
        <div>
		<label class=label>address</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="add" required>
        </div>
        <div>
		<label class=label>contact</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="ph" required>
        </div>
        <div>
        <center> <input type="submit" class=sbtn name="insertd" value="insert" ></center>
        </div>
        <div style=" padding:10px; text-align: right">
        <a href="viewd.php">View table</a>  
        </div>
        </form>
        </div>
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="adminmainpage.php"> <h3>Back</h3></a>  </p>

    </div>
       
        </section>
        
    </body> 
</html>

<?php
if(isset($_POST['insertd']))
{
    $con=mysqli_connect('localhost','root','','farmer_db');
    $d=$_POST['D_id'];
    $f=$_POST['fname'];
    $l=$_POST['lname'];
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $org=$_POST['org'];
    $ph=$_POST['ph'];
    $add=$_POST['add'];
    $sqld="insert into dealer(D_id,fname,lname,email,password,organization,address,contact) values
     ('$d','$f','$l','$email','$pass','$org','$add','$ph');";
    $query=mysqli_query($con,$sqld);
    echo "insert sucessful";
}   
?>
