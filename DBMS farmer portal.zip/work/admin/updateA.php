<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
?>
<?php
    if(isset($_POST['update']))
    {
     $con=mysqli_connect('localhost','root','','farmer_db');      
    $id=$_POST['Ag_id'];
    $fn=$_POST['fname'];
    $ln=$_POST['lname'];
    $em=$_POST['email'];
    $pw=$_POST['password'];    
    $ph=$_POST['ph'];
    $add=$_POST['add'];
    if($fn)
    {
    $sql="update agri_officer set fname='$fn'where Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($ln)
    {
    $sql="update agri_officer set lname='$ln'where Ag_id='$id";
    $query=mysqli_query($con,$sql);
    }
    if($em)
    {
    $sql="update agri_officer set email='$em' where Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($pw)
    {
    $sql="update agri_officer set password='$pw' where  Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($org)
    {
    $sql="update agri_officer set orgnisation='$org' where Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($add)
    {
    $sql="update agri_officer set address='$add' where Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($ph)
    {
    $sql="update agri_officer set contact='$ph' where Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    echo " Update sucessful ";
    header('location:viewa.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>update agri_officer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Agri_ofiicer</h1>
           <br>
        <div class="insertbox">
        <form action="updateA.php" method="post">
        <div>
            <label class=label>Ag_id</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="Ag_id" required>
        </div>
		<div>
		<label class=label>fname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="fname"  > 
        </div>
        <div>
		<label class=label>lname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="lname" >
        </div>
        <div>
        <label class=label >email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="email" >
        </div>
        <div>
        <label class=label>password</label>&nbsp&nbsp&nbsp&nbsp
		<input type="password" name="password" >
        </div>
        <div>
		<label class=label>address</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="add" >
        </div>
        <div>
		<label class=label>contact</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="ph" >
        </div>
        <div>
        <center><input type="submit" name="update" value="update" ></center>
        </div>
        <div style=" padding:10px; text-align: right">
        <a href="viewa.php">View table</a>  
        </div>
        </form>
        </div>
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="adminmainpage.php"> <h3>Back</h3></a>  </p>

    </div>
       
        </section>
    </body> 
</html>
