<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>view agri_officer</title>
       <link href="../css/tablestyle.css" rel="stylesheet" type="text/css">
        
    </head>
    <body>
    <center><a href="adminmainpage.php"> <h3>Admin home</h3></a></center>        
<?php
    $con=mysqli_connect('localhost','root','','farmer_db');
    $s=mysqli_query($con,"select * from agri_officer");

?>
<center>
<table class=conttable>
    <thead>
    <tr>
    <th>Ag_id</th>
    <th>Fname</th>
    <th>Lname</th>
    <th>address</th>
    <th>E-mail</th>
    <th>Contact</th>
    <th></th>
    </tr>
    </thead>
    <?php 
    while($r=mysqli_fetch_array($s))
    {
    ?>
    <tbody>
    <tr>
    <td><?php echo $r['Ag_id'];?> </td>
    <td><?php echo $r['fname'];?> </td>
    <td><?php echo $r['lname'];?> </td>
    <td width=200px;><?php echo $r['address'];?> </td>    
    <td><?php echo $r['email'];?> </td>
    <td><?php echo $r['contact'];?> </td>
    <td><a href='deletea.php?i=<?php echo $r['Ag_id'] ?> '><button>delete</button></a></td>
    </tr>
    </tbody>
    
    <?php
    }
    ?>
    </table>
</center>
    <div>
    <center> <a href="updateA.php"> update table data</a></center>
    </div>
    </body>     
</html>
