<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>register agri_officer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Agri officer</h1>
           <br>
        <div class="insertbox">
        <form action="registera.php" method="post">
            <div>
            <label class=label>Ag_ id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="Ag_id" required>
        </div>
		<div>
		<label class=label>fname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="fname" required> 
        </div>
        <div>
		<label class=label>lname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="lname" required>
        </div>
        <div>
            <label class=label >email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="email" required>
        </div>
        <div>
        <label class=label>password</label>&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="password" name="password" required>
        </div>
        <div>
		<label class=label>address</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="textarea" name="add" required>
        </div>
        <div>
		<label class=label>contact</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="ph" required>
        </div>
        <div>
        <center>  <input type="submit" name="inserta" value="insert" class=sbtn></center>
        </div>
        <div style="padding:10px; text-align:right">
        <a href="viewa.php">View table</a>  
        </div>
        </form>
        </div>
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="adminmainpage.php"> <h3>Back</h3></a>  </p>
    </div>
    </section>
    </body> 
</html>
<?php
if(isset($_POST['inserta']))
{
    $con=mysqli_connect('localhost','root','','farmer_db');
    $a=$_POST['Ag_id'];
    $f=$_POST['fname'];
    $l=$_POST['lname'];
    $email=$_POST['email'];
    $pass=$_POST['password'];
    $ph=$_POST['ph'];    
    $add=$_POST['add'];    
    $sqla="insert into agri_officer(Ag_id,fname,lname,email,password,address,contact) values
     ('$a','$f','$l','$email','$pass','$add','$ph');";

    $query=mysqli_query($con,$sqla);
    echo "<div style='box-shadow:1px 1px 5px 1px rbg(255,90,40);'>insert sucessful....!";

    
}

?>