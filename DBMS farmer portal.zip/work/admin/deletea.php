<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>delete agri_officer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Agri officer</h1>
           <br>
        <div class="insertbox">
        <form action="deletea.php" method="post">
            <div>
            <label class=label>Ag_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="Ag_id" required>
            </div>
            <div>
            <center><input type="submit" name="delete" value="Delete" class=sbtn></center>            
            </div>
            </form>
            
        </div>
        
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <center><a href="adminmainpage.php"> <h3>Back</h3></a> </center>


        </body>
    </html>

    <?php
    
    if(isset($_POST['delete']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['Ag_id'];
    $sql="delete from agri_officer where Ag_id='$id'";
    $query=mysqli_query($con,$sql);
    if($query==TRUE)
    {
    echo "delete sucessful";    
    header('location:adminmainpage.php');
    }
    else
    {
    echo "delete unsucessful";
    header("location:deletea.php"); 
    }
    }
    elseif(isset($_GET['i']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_GET['i'];
    echo "$id";
    $sql="delete from agri_officer where Ag_id='$id'";
    $query=mysqli_query($con,$sql); 
    header('location:viewa.php');
    }
    ?>