<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }

?>
 
<?php
    if(isset($_POST['update']))
    {
     $con=mysqli_connect('localhost','root','','farmer_db');
        
    $id=$_POST['D_id'];
    $fn=$_POST['fname'];
    $ln=$_POST['lname'];
    $em=$_POST['email'];
    $pw=$_POST['password'];    
    $org=$_POST['org'];
    $ph=$_POST['ph'];
    $add=$_POST['add'];
    
    if($fn)
    {
    $sql="update dealer set fname='$fn'where D_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($ln)
    {
    $sql="update dealer set lname='$ln'where D_id='$id";
    $query=mysqli_query($con,$sql);
    }
    if($em)
    {
    $sql="update dealer set email='$em' where D_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($pw)
    {
    $sql="update dealer set password='$pw' where D_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($org)
    {
    $sql="update dealer set orgnisation='$org' where D_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($add)
    {
    $sql="update dealer set address='$add' where D_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($ph)
    {
    $sql="update dealer set contact='$ph' where D_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    echo " Update sucessful ";
    header('location:viewd.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>update dealer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Dealer</h1>
           <br>
        <div class="insertbox">
        <form action="updateD.php" method="post">
        <div>
            <label class=label>D_id</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="D_id" required>
        </div>
		<div>
		<label class=label>fname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="fname"  > 
        </div>
        <div>
		<label class=label>lname</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="lname" >
        </div>
        <div>
            <label class=label >email</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="email" >
        </div>
        <div>
        <label class=label >organization</label>
		<input type="text" name="org" >
        </div>
        <div>
        <label class=label>password</label>&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="password" name="password" >
        </div>
        <div>
		<label class=label>address</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="add" >
        </div>
        <div>
		<label class=label>contact</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="ph" >
        </div>
        <div>
        <center>  <input type="submit" name="update" value="update" ></center>
        </div>
        <div style=" padding:10px; text-align: right">
        <a href="viewd.php">View table</a>  
        </div>
        </form>
        </div>
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="adminmainpage.php"> <h3>Back</h3></a>  </p>

    </div>
       
        </section>
    </body> 
</html>
