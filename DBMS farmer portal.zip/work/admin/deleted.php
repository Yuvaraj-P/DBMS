<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>delete dealer</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Dealer</h1>
           <br>
        <div class="insertbox">
        <form action="deleted.php" method="post">
            <div>
            <label class=label>D_ id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="D_id" required>
            </div>
            <div>
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
          <center>  <input type="submit" name="delete" value="delete" class=sbtn></center>
            </div>
            </form>
            
        </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <center><a href="adminmainpage.php"> <h3>Back</h3></a> </center>

        </body>
    </html>

    <?php
    
    if(isset($_POST['delete']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['D_id'];
    $sqld="delete from dealer where D_id='$id'";
    $query=mysqli_query($con,$sqld);
    if($query==TRUE)
    {
    echo "delete sucessful";    
    header('location:adminmainpage.php');
    }
    else
    {
    echo "delete unsucessful";
    header("location:deleted.php"); 
    }
    }
    elseif(isset($_GET['i']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_GET['i'];
    echo "$id";
    $sqld="delete from dealer where D_id='$id'";
    $query=mysqli_query($con,$sqld); 
    header('location:viewd.php');
    } 
    ?>