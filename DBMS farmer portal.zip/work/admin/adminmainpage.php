<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
    $email=$_SESSION['user'];
    $con=mysqli_connect('localhost','root','','farmer_db');        
    $sql="select A_id,fname from admin where email='$email'";
    $q=mysqli_query($con,$sql);
    $r=mysqli_fetch_array($q); 
?>
<?php include("../partials/header.php");?>
        <section>
        <nav class="padd" >
        <ul >   
        <li><i class="fa fa-th-list" aria-hidden="true"></i> Agri_officer  <i class="fa fa-sort-desc" aria-hidden="true"></i>
        <ul>
        <li><a href="registera.php">insert</a></li>
        <li><a href="deletea.php">delete</a></li>
        <li><a href="updateA.php">update</a></li>
        </ul>
        </li>
        <li><i class="fa fa-th-list" aria-hidden="true"></i>  Dealer <i class="fa fa-sort-desc" aria-hidden="true"></i>
        <ul>   
        <li><a href="registerd.php">insert</a></li>
        <li><a href="deleted.php">delete</a></li>
        <li><a href="updateD.php">update</a></li> 
        </ul>
        </li>
        <li><i class="fa fa-eye" aria-hidden="true"></i> View <i class="fa fa-sort-desc" aria-hidden="true"></i> 
        <ul>
        <li><a href="viewa.php">agri_officer</a></li>            
        <li> <a href="viewd.php"> dealer</a></li>
        </ul>
        <li style="width:10px;float:left;"><i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        <ul>
        <li><a href="../login/logout.php"> LOG OUT</a></li>
        </ul>
        </li>
        </div>
        </ul> 
        
        </nav>
        <br>
        <hr>
        <div  >
        <div class="jumbotron container" id="jumbo">
        <h2>WELCOME </h2>&nbsp&nbsp&nbsp<?php echo "$r[fname]"; ?>   
        <form class="form-inline  my-lg-0" method="post" action="adminmainpage.php" >
        <br>   
        <input name="id" class="form-control mr-sm-2" type="search" placeholder="Enter the Id" aria-label="Search">
           <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="serc"><i class="fa fa-search" aria-hidden="true"></i></button>
           </form> 
        </div>  
        </div>
        </section>
        <ul class="list">
        <li><a href="../farmer/viewf.php"><i class="fa fa-eye" aria-hidden="true"></i> view farmers </a></li>
        <li><a href="../dealer/viewp.php"><i class="fa fa-eye" aria-hidden="true"></i> view product</a></li>
        <li><a href="../agri_off/viewac.php"><i class="fa fa-eye" aria-hidden="true"></i> view commodity</a></li>
        </ul>
        <br><br><br>

    <?php
    if(isset($_POST['serc']))
    {
        $id=$_POST["id"];
        $con=mysqli_connect('localhost','root','','farmer_db');
        $a=mysqli_query($con,"select * from agri_officer where Ag_id=$id");
        $d=mysqli_query($con,"select * from dealer where D_id=$id");   
    
        if($a){
        $r=mysqli_fetch_array($a);           
        if($r['Ag_id'])
        {
        ?>
            <center>
            <table class=conttable style="background:black; opacity:.8;">
                <thead>
                <tr>
                <th>Ag_id</th>
                <th>Fname</th>
                <th>Lname</th>
                <th>address</th>
                <th>E-mail</th>
                <th>Contact</th>
                <th></th>
                </tr>
                </thead>
                <tbody>
                <tr>
                <td><?php echo $r['Ag_id'];?> </td>
                <td><?php echo $r['fname'];?> </td>
                <td><?php echo $r['lname'];?> </td>
                <td width=200px;><?php echo $r['address'];?> </td>    
                <td><?php echo $r['email'];?> </td>
                <td><?php echo $r['contact'];?> </td>
                <td><a href='../agri-off/deletea.php?i=<?php echo $r['Ag_id'] ?> '><button>delete</button></a></td>
                </tr>
                </tbody>
                </table>
        </center>
    <?php
    } 
}
    ?>

    <?php    
        if($d){
        $s=mysqli_fetch_array($d);
        if($s['D_id']!=NULL)
        {
            ?>
            <center>
            <table class=conttable style="background:black; opacity:.8;">
            <thead>
            <tr>
            <th>D_id</th>
            <th>Fname</th>
            <th>Lname</th>
            <th>Address</th>
            <th>E-mail</th>
            <th>Contact</th>
            <th>Organization</th>
            <th></th>
            </tr>
            </thead>
            <tdata>
            <tr>
            <td><?php echo $s['D_id'];?> </td>
            <td><?php echo $s['fname'];?> </td>
            <td><?php echo $s['lname'];?> </td>
            <td width=200px;><?php echo $s['address'];?> </td>    
            <td><?php echo $s['email'];?> </td>
            <td><?php echo $s['contact'];?> </td>    
            <td><?php echo $s['organization'];?> </td>
            <td><a href='../dealer/deleted.php?i=<?php echo $s['D_id'] ?> '><button> delete </button></a></td>
            </tr>
            </tdata>
            </table>
            </center>
        <?php
        }
        }
    } 
?>
<?php include("../partials/footer.php");?>