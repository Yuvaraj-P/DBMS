<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <title>insert product</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
    <h1 style="color:white; text-align:center;" >Product</h1>
           <br>
        <div class="insertbox">
        <form action="insertp.php" method="post">
            <div>
            <label class=label>P_id</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="id" required>
            </div>
		<div>
		<label class=label>P_name</label>&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="name" required> 
        </div>
        <div>
		<label class=label>descp</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="desc" required>
        </div>
        <div>
            <label class=label>price</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="price" required>
        </div>
        <div>
        <label class=label>type</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="ty" requierd>
        <!-- value="<select> 
            <option value="seed">seed</option>
            <option value="fertilizer">fertilizer</option>
            <option value="farmmachinery">farmmachinery</option> 
        </select>" -->       
        </div>
        <div>
        <label class=label>D_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="did" required>
        </div>
        <div>
        <label class=label>rent</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="rent" >
        </div>
        <div>
        <center> <input type="submit" class=sbtn name="insert" value="insert" ></center>
        </div>
        <div style=" padding:10px; text-align: right">
        <a href="viewp.php">View table</a>  
        </div>
    </form>
   

    </div>
    <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="dealermainpage.php"> <h3>Back</h3></a>  </p>
    </div>
        </section>
        
    </body> 
</html>

<?php
if(isset($_POST['insert']))
{
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['id'];
    $n=$_POST['name'];
    $desc=$_POST['desc'];
    $p=$_POST['price'];
    $ty=$_POST['ty'];
    $did=$_POST['did'];
    $r=$_POST['rent'];
    $sql="insert into product(P_id,name,descp,price,type,D_id,rent)
    values ('$id','$n','$desc','$p','$ty','$did','$r');";
    $query=mysqli_query($con,$sql);
    echo "insert sucessful";
}   
?>
