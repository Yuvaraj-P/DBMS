<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
?>
<?php
    if(isset($_POST['update']))
    {
     $con=mysqli_connect('localhost','root','','farmer_db');

     $id=$_POST['id'];
     $n=$_POST['name'];
     $desc=$_POST['desc'];
     $p=$_POST['price'];
     $ty=$_POST['ty'];
     $did=$_POST['did'];
     $r=$_POST['rent'];
    if($n)
    {
    $sql="update product set name='$n' where P_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($desc)
    {
    $sql="update product set descp='$desc' where P_id='$id'";        
    $query=mysqli_query($con,$sql);
    }
    if($p)
    {
    $sql="update product set price='$p' where P_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($ty)
    {
    $sql="update product set type='$ty'where P_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($did)
    {
    $sql="update product set D_id='$did'where P_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($r)
    {
    $sql="update product set rent='$r' where P_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    echo " Update sucessful ";
    header('location:viewp.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>update product</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >product</h1>
           <br>
        <div class="insertbox">
        <form action="updatep.php" method="post">
        <div>
        <label class=label>P_id</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="id" required>
        </div>
    <div>
    <label class=label>P_name</label>&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="name" > 
    </div>
    <div>
    <label class=label>descp</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="desc" >
    </div>
    <div>
        <label class=label>price</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="price" >
    </div>
    <div>
    <label class=label>type</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="ty" >      
    </div>
    <div>
    <label class=label>D_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="did" >
    </div>
    <div>
    <label class=label>rent</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    <input type="text" name="rent" >
    </div>
    <div>
    <center> <input type="submit" class=sbtn name="update" value="update" ></center>
    </div>
    <div style=" padding:10px; text-align: right">
    <a href="viewp.php">View table</a>  
    </div>
    </form>
        </div>
        
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="dealermainpage.php"> <h3>Back</h3></a>  </p>

    </div>
       
        </section>
    </body> 
</html>
