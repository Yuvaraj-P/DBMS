<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/dealerlogin.php");
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>delete product</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Product</h1>
           <br>
        <div class="insertbox">
        <form action="deletep.php" method="post">
        <div>
        <label class=label>P_ id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="id" required>
            </div>
            <div>
            <center>  <input type="submit" name="delete" value="delete" class=sbtn></center>
            </div>
            </form>
            
        </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <center><a href="dealermainpage.php"> <h3>Back</h3></a> </center>

        </body>
    </html>

    <?php
    
    if(isset($_POST['delete']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['id'];
    $sql="delete from product where P_id='$id'";
    $query=mysqli_query($con,$sql);
    if($query==TRUE)
    {
    header('location:dealermainpage.php');
    echo "delete sucessful";    
    }
    else
    {
    header("location:deletep.php"); 
    echo "delete unsucessful";    
    }
    }
    elseif(isset($_GET['i']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_GET['i'];
    echo "$id";
    $sql="delete from product where P_id='$id'";
    $query=mysqli_query($con,$sql); 
    header('location:viewp.php');
    } 
    ?>