<!DOCTYPE html>
<html>
    <head>
        <title>Login page</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    <header >
    &nbsp
    <div class="navbar-brand " style="background-color:darkgreen; width:115px; color:white; margin:2px;">
     &nbsp&nbsp<i class="fa fa-leaf" aria-hidden="true"></i> E-farm       
    </div>
<nav style="padding:5px;" >
            <ul>
            <li><a href="../index.php">| <i class="fa fa-home" aria-hidden="true"></i> HOME</a></li>            
            <li><a href="../statistic.php"> | <i class="fa fa-map" aria-hidden="true"></i> Map</a> </li> 
            <li><a href="../agrimall.php">| <i class="fa fa-building" aria-hidden="true"></i> AGRIMALL</a></li>
            <li> | <i class="fa fa-user" aria-hidden="true"></i>  LOGIN
            <ul>
            <li><a href="../login/adminlogin.php" >  Admin  </a></li>
            <li><a href="../login/aflogin.php">   Agri_officer</a></li>
            <li><a href="../login/dealerlogin.php">  Dealers</a></li>
            <li><a href="../login/farmerlogin.php">  Farmer</a></li>
            </ul>
            </li>
            <li><a href="../about.php">| <i class="fa fa-info-circle    " aria-hidden="true"></i>  ABOUT us</a></li>  
         </ul>
</nav>
    </ul>