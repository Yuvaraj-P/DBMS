<div class="foot"  >
    <p>
    
    <br>&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp<div class="navbar-brand " style="background-color:green; width:115px; color:white; margin:2px;">
     <i class="fa fa-leaf" aria-hidden="true"></i> E-farm       
                                      </div><br><br>
                                      <div STYLE="FLOAT:RIGHT; margin-right:10%;">
     &nbsp&nbsp&nbsp&nbsp&nbsp| <i class="fa fa-address-card-o" aria-hidden="true"></i>&nbsp adddress |<br>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  #11/3rd cross Nandidurga Road 
     <br> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Banglore,karnataka-560046 
    <br>&nbsp&nbsp&nbsp <hr style="width:300px;float:left;margin:20px; boder:1px soild white;">

</div> 
    
    &nbsp&nbsp&nbsp&nbsp&nbsp | contact us   <i class="fa fa-phone" aria-hidden="true"></i> | &nbsp +91 9898989898

    <br>
    &nbsp&nbsp&nbsp&nbsp&nbsp | <i class="fa fa-envelope-o" aria-hidden="true"></i> E-mail  | &nbsp xyz@gmail.com
    
    <br>&nbsp&nbsp&nbsp <hr style="width:300px;float:left;margin:20px; boder:1px soild white;">
    <br><br>

    &nbsp&nbsp&nbsp&nbsp&nbsp| Disclaimer | <br>
    &nbsp&nbsp&nbsp&nbsp&nbsp  Designed, developed and hosted by E-farm Private.ltd

    <br>
     <br><br>
     <center>
     This website belongs to Department of Agriculture & Cooperation,<br>
        E-farm &nbsp&nbsp&nbsp ,Ministry of Agriculture.
</center>

<br><br>
    </p>
    <script src="../bootstrap/js/jquery-3.4.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    
</body>
</html>