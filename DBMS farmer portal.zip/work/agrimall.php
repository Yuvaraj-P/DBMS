<?php
include("partials/head.php"); 
?>
<link rel="stylesheet" href="css/tablestyle.css">
<br>
    <hr>
            <div>
            <h5>&nbsp&nbsp&nbsp&nbsp&nbspAGRIMALL</h5>
    <section>
    <?php
    $con=mysqli_connect('localhost','root','','farmer_db');
    $s=mysqli_query($con,"select * from agri_mall a,farmer f where a.F_id=f.F_id ");

    ?>
<center>
<table class=conttable style="background:white;">
    <thead>
    <tr>
    <th>M_id</th>
    <th>Crop_id</th>
    <th>price/quintal</th>
    <th>Qty(quintal)</th>
    <th>Fname</th>
    <th>Email</th>
    <th>Image</th>
    </tr>
    </thead>
    <?php 
    while($r=mysqli_fetch_array($s))
    {
    ?>
    <tbody>
    <tr>
    <td><?php echo $r['M_id'];?> </td>
    <td><?php echo $r['C_id'];?> </td>
    <td><?php echo $r['price'];?> </td>
    <td><?php echo $r['quintal'];?> </td>
    <td><?php echo $r['fname'];?> </td>
    <td><?php echo $r['email'];?> </td>
    <div class="imgdiv">
    <td><?php echo "<img src='uploads/".$r['img']."'>";?></td>
    </div>
    </tr>
    </tbody>
    
    <?php
    }
    ?>
    </table>
    </center>
            </section>
            </div>
        </header>


        <?php
include("partials/foot.php");

?>