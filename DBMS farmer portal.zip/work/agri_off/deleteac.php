<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/aflogin.php");
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>delete commodity</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Agri commodity</h1>
           <br>
        <div class="insertbox">
        <form action="deleteac.php" method="post">
            <div>
            <label class=label>C_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="id" required>
            </div>
            <div>
            <center><input type="submit" name="delete" value="Delete" class=sbtn></center>            
            </div>
            </form>
            
        </div>
        
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <center><a href="adminmainpage.php"> <h3>Back</h3></a> </center>


        </body>
    </html>

    <?php
    
    if(isset($_POST['delete']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['id'];
    $sql="delete from agri_commodity where C_id='$id'";
    $query=mysqli_query($con,$sql);
    if($query==TRUE)
    {
    header('location:afmainpage.php');
    echo "delete sucessful";        
    }
    else
    {
    echo "delete unsucessful";
    header("location:deleteac.php"); 
    }
    }
    elseif(isset($_GET['i']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_GET['i'];
    echo "$id";
    $sql="delete from agri_commodity where C_id='$id'";    
    $query=mysqli_query($con,$sql); 
    header('location:viewac.php');
    }
    ?>