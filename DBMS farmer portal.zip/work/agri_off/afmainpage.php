<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
    
    $email=$_SESSION['user'];
    $con=mysqli_connect('localhost','root','','farmer_db');        
    $sql="select Ag_id,fname from agri_officer where email='$email'";
    $q=mysqli_query($con,$sql);
    $r=mysqli_fetch_array($q); 
?>
<?php include("../partials/header.php");?>
<section>
    <nav class="padd" >
    <ul>
        <li><i class="fa fa-pagelines" aria-hidden="true"></i> Agri commodity  
        <i class="fa fa-sort-desc" aria-hidden="true"></i>
        <ul>   
        <li><a href="insertac.php">insert</a></li>
        <li><a href="deleteac.php">delete</a></li>
        <li><a href="updateac.php">update</a></li> 
        </ul>
        </li>
        <li><a href="viewac.php"><i class="fa fa-eye" aria-hidden="true"></i> view commodity </a>
        </li>
        <li style="width:10px;"><i class="fa fa-ellipsis-v" aria-hidden="true"></i>
        <ul>
        <li><a href="../login/logout.php"> LOG OUT</a></li>
        </ul>
        </ul>  
    </nav>
        <br>
        <hr>
        <div class="jumbotron container" id="jumbo">
        <h2>WELCOME </h2>&nbsp&nbsp&nbsp<?php echo "$r[fname]"; ?>   
        </div>  
        </section>
        <ul>
        <li><a href="../farmer/viewf.php"> <i class="fa fa-eye" aria-hidden="true"></i> view farmers </a></li>        
        </ul>
    </body> 
</html>