<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/aflogin.php");
    }

?>
<!DOCTYPE html>
<html>
    <head>
        <title>insert commodity</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >commodity</h1>
           <br>
        <div class="insertbox">
        <form action="insertac.php" method="post">
            <div>
            <label class=label>C_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="id" required>
            </div>
		<div>
		<label class=label>Crop_name</label>
        <input type="text" name="name" required> 
        </div>
        <div>
		<label class=label>type</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="type" required> 
        </div>
        <div>
            <label class=label >description</label>&nbsp
		<input type="textarea" name="desc" required>
        </div>
        <div>
        <label class=label>season</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="season" required>
        </div>
        <div>
      <center>  <input type="submit" name="insert" value="insert" class=sbtn></center>

        </div>
        <div style=" padding:10px; text-align: right">
        <a href="viewac.php">View table</a>  
        </div>
        </form>

        </div>
        
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="afmainpage.php"> <h3>Back</h3></a>  </p>

    </div>
       
        </section>
    </body> 
</html>

<?php

if(isset($_POST['insert']))
{
    $con=mysqli_connect('localhost','root','','farmer_db');
    $a=$_POST['id'];
    $n=$_POST['name'];
    $type=$_POST['type'];
    $desc=$_POST['desc'];
    $season=$_POST['season'];
    $sql="insert into agri_commodity(C_id,C_name,type,descp,season) values
     ('$a','$n','$type','$desc','$season');";

    $query=mysqli_query($con,$sql);
    echo "insert sucessful....!";
}

?>