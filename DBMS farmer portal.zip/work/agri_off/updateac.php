<?php
    session_start();
    if(!isset($_SESSION['user']))
    {
        header("location:../login/adminlogin.php");
    }
?>
<?php
    if(isset($_POST['update']))
    {
    $con=mysqli_connect('localhost','root','','farmer_db');
    $id=$_POST['id'];
    $n=$_POST['name'];
    $type=$_POST['type'];
    $desc=$_POST['desc'];
    $season=$_POST['season'];    
    if($n)
    {
    $sql="update agri_commodity set c_name='$n'where C_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($type)
    {
    $sql="update agri_commodity set type='$type'where C_id='$id'";
    $query=mysqli_query($con,$sql);
    }
    if($desc)
    {
    $sql="update agri_commodity set descp='$desc'where C_id='$id'";        
    $query=mysqli_query($con,$sql);
    }
    if($season)
    {
    $sql="update agri_commodity set season='$season'where C_id='$id'";        
    $query=mysqli_query($con,$sql);
    }
    
    header('location:viewac.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>update commodity</title>
        <link href="../css/mainstyle.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <h1 style="color:white; text-align:center;" >Agri commodity</h1>
           <br>
        <div class="insertbox">
        <form action="updateac.php" method="post">
        <div> <label class=label>C_id</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="text" name="id" required>
            </div>
		<div>
		<label class=label>Crop_name</label>
        <input type="text" name="name" > 
        </div>
        <div>
		<label class=label>type</label> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="type" > 
        </div>
        <div>
            <label class=label >description</label>&nbsp
		<input type="textarea" name="desc" >
        </div>
        <div>
        <label class=label>season</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
		<input type="password" name="season" >
        </div>
        <div>
        <center><input type="submit" name="update" value="update" ></center>
        </div>
        <div style=" padding:10px; text-align: right">
        <a href="viewac.php">View table</a>  
        </div>
        </form>
        </div>
        <div style="text-align:center;">
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a href="afmainpage.php"> <h3>Back</h3></a>  </p>
    </div>
        </section>
    </body> 
</html>
